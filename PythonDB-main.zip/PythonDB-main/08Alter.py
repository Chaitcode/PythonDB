import pymysql

con=pymysql.connect(host='bspxvqia9n5bvu0dkdle-mysql.services.clever-cloud.com',user='usiwf9f6sejtxk1w',password='W9n86OMTC0sSqE3TaVDr',database='bspxvqia9n5bvu0dkdle')
curs=con.cursor()
curs.execute("alter table MOBILES add Purpose varchar(50)")
con.commit()
print("new column added successfully...")
con.close()